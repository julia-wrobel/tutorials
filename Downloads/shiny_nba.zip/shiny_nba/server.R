#
# This is the server logic of a Shiny web application. You can run the 
# application by clicking 'Run App' above.

library(shiny)
library(tidyverse)

# Define server logic 
shinyServer(function(input, output) {
   
  # set range of seasons based on player choice
  output$season_choice <- renderUI({
    seasons = nba_shots %>% filter(player_name == input$player_choice) %>% 
      distinct(season) %>% pull()
    
    selectInput("season_choice", label = "Select season", choices = seasons,
                selected = seasons[1])
  })
  
  
  output$court_shots <- renderPlot({
    # define and create plots here
  })
  

})
